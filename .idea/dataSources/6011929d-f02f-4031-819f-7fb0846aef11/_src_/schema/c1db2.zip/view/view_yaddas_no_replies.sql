CREATE VIEW view_yaddas_no_replies AS
  SELECT
    `y`.`YaddaID`                           AS `YaddaID`,
    `y`.`Text`                              AS `Text`,
    `y`.`Username`                          AS `Username`,
    `y`.`DateAndTime`                       AS `DateAndTime`,
    `y`.`lft`                               AS `lft`,
    `y`.`rght`                              AS `rght`,
    (SELECT count(`r`.`YaddaID`)
     FROM `c1db2`.`Reply` `r`
     WHERE (`r`.`YaddaID` = `y`.`YaddaID`)) AS `replies`
  FROM `c1db2`.`Yadda` `y`
  WHERE (NOT (`y`.`YaddaID` IN (SELECT `r`.`YaddaIDReply`
                                FROM `c1db2`.`Reply` `r`)))
  ORDER BY `y`.`DateAndTime` DESC, `y`.`YaddaID`;
