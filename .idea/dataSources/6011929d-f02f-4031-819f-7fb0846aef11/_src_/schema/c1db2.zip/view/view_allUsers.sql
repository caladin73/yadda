CREATE VIEW view_allUsers AS
  SELECT
    `c1db2`.`Users`.`Username`    AS `Username`,
    `c1db2`.`Users`.`Password`    AS `Password`,
    `c1db2`.`Users`.`Name`        AS `Name`,
    `c1db2`.`Users`.`Email`       AS `Email`,
    `c1db2`.`Users`.`ProfilImage` AS `ProfilImage`,
    `c1db2`.`Users`.`Admin`       AS `Admin`,
    `c1db2`.`Users`.`Activated`   AS `Activated`
  FROM `c1db2`.`Users`;
